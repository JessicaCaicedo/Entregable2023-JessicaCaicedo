import Formulario from "./components/Formulario";

function App() {
  //Aqui deberias agregar los estados y los handlers para los inputs

  return (
    <div className="App">
      <h1 className="bienvenido">Bienvenido</h1>
      <Formulario/>
    </div>
  );
}

export default App;
